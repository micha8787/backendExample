import io
import os
from os import listdir
from flask import Flask, jsonify,render_template;
from flask_cors import CORS;
import json
import base64
import numpy as np
import cv2

# from flask_restful import Resource, Api;


app = Flask(__name__)
# api=Api(app)
CORS(app)
img = {}
firstImg ={}
secondImg = {}

def image_encoder(image_path,file_to_save_the_image):
    with open(image_path, mode='rb') as file:
        img = file.read()
    file_to_save_the_image['img'] = base64.encodebytes(img).decode("utf-8")


@app.route("/", methods=['GET'])
def index():
    return render_template();

@app.route("/???/", methods = ['GET'])
def WeatherReport():
    global firstImg
    global secondImg
    return jsonify([firstImg,secondImg])

if __name__ == '__main__':
    # you need to change the path at the line above to the images folder's path.
     path_file = 'C:/Users/micha87/.PyCharm2019.3/config/scratches/example_images/'
     my_files = listdir(path_file)
     for i in range(len(my_files)):
        if (i%2 == 0):
            first_file = my_files[i]
            first_file = path_file+first_file
            second_file = my_files[i+1]
            second_file = path_file+ second_file
            image_encoder(first_file,firstImg)
            image_encoder(second_file,secondImg)
            app.run(debug=True)









