import io
import os
from os import listdir
from flask import Flask, jsonify,render_template;
from flask_cors import CORS;
import json
import base64
import numpy as np


# from flask_restful import Resource, Api;


app = Flask(__name__)
# api=Api(app)
CORS(app)




@app.route("/", methods=['GET'])
def index():
    return render_template();

@app.route("/???/", methods = ['GET'])
def example():
    global firstImg
    global secondImg
    return [first_file,second_file]

if __name__ == '__main__':
    # you need to change the path at the line above to the images folder's path.
     path_file = './example_images/'
     my_files = listdir(path_file)
    #looping through all the couples of images
     for i in range(len(my_files)):
        if (i%2 == 0):
            first_file = my_files[i]
            first_file = path_file+first_file
            print(os.path.isfile(first_file))#checking if the specified file is a real file
            second_file = my_files[i+1]
            second_file = path_file+ second_file #checking if the specified file is a real file
            print(os.path.isfile(second_file))
            app.run(debug=True)









